 function demonclick(){
    atert ("on click");
 }

 function demonclick(){ 
    alert("on double click");
 }

 function demofocus(){
    document.getElementById("textfocus").style.backgroundcolor="yellow";
 }

 function demoonblur(){
    document.getElementById("textblur").style.backgroundColor="blue";
 }

 function demoonkeypress(){
    alert ("keypress done");
 }

 function demokeyup(){
    alert ("keyup done");
 }