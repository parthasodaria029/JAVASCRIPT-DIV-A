const country =["India","USA","Japan"]
for(C of country){
    document.write("<be/>"+C);/
}