var x=50;
x +=70;
document.write(x);