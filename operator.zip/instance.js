//typeof
//array instance of 
var a = ["silver","ork"];
document.write(a instanceof Array);

document.write("<br/>");

//class instance of
class ractangle {
    constructor(height,width){
        this.height=height;
        this.write=width;
    }
}
var R=new ractangle(10,20);
document.write(R instanceof ractangle);

document.write("<br/>");


document.write(R.height+R.width);