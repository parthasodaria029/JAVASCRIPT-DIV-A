let n1=20,n2=30;

var sum=n1+n2,sub=n1-n2,div=n1/n2,mod=n1%n2
var Exponention=5**2;// same as pow.
document.write("<dr/.sum:",sum+"<dr/>mu1:",mul+"<br/sub:",sub+"<br/>Div:",div+"<br/>");




